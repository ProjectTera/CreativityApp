package com.example.soundboardapp;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn1, btn2,btn3,btn4;
    int[][] ids;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);

        ids = new int[][] {{R.id.btn1, R.raw.winner}
                            , {R.id.btn2, R.raw.loser}
                            , {R.id.btn3, R.raw.tryagain}
                            , {R.id.btn4, R.raw.giveup}};
    }

    @Override
    public void onClick(View v) {

        int clickedBtnId = v.getId();

        for (int i = 0; i < ids.length; i++) {
            if (ids[i][0] == clickedBtnId) {
                MediaPlayer mediaPlayer = MediaPlayer.create(
                        getApplicationContext()
                        , ids[i][1]
                );

                mediaPlayer.start();
                break;
            }
        }
    }
}