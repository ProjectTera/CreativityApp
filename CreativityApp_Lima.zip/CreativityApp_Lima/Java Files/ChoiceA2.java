package com.example.lima_creativityapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ChoiceA2 extends AppCompatActivity {

    ConstraintLayout backgroundLayout;
    Button homebtn;
    TextView storytext;
    int currentIndex = 0;

    public MediaPlayer storyaudio;

    int[] audio = new int[]{R.raw.a2_part1, R.raw.a2_part2, R.raw.a2_part3, R.raw.a2_part4};

    String[] story = new String[]{"You lie motionless on the floor, pretending to be unconscious.  ",
            "The creature approaches, its breath hot and fetid. \n",
            "It leans in close, its red eyes boring into yours and flashed brightly. ",
            "Suddenly, you lost unconcious. The next thing you saw was a bright light which felt warm.\n\n" +
                    "You followed the light, and it seems to take you somewhere but it made you walk endlessly.\n\n" +
                    "You thought \"Could this be salvation or was there another choice I could've made ?\".\n\n" +
                    "END (A WANDERING SOUL)"

    };

    int[] backgroundImages = new int[]{
            R.drawable.corridor,
            R.drawable.glowingredeyes,
            R.drawable.glowingredeyes,
            R.drawable.brightlight
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_a2);
        storytext = findViewById(R.id.storytext);
        backgroundLayout = findViewById(R.id.backgroundLayout5);

        homebtn = findViewById(R.id.homebtn);

        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAndReleaseMediaPlayerss();
                Intent gohome = new Intent(ChoiceA2.this, Game.class);
                gohome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(gohome);
            }
        });

        playNextAudio();
    }

    public void playNextAudio() {
        if (currentIndex < audio.length) {
            storytext.setText(story[currentIndex]);
            storyaudio = MediaPlayer.create(getApplicationContext(), audio[currentIndex]);
            backgroundLayout.setBackgroundResource(backgroundImages[currentIndex]);

            storyaudio.start();

            // Play specific sound effects at certain audio indices
            if (currentIndex == 0) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.fellunconcious);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            } else if (currentIndex == 1) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.monsterbreath);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }else if (currentIndex == 2) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.flashbrightly);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }else if (currentIndex == 3) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.fellunconcious);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }

            storyaudio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    currentIndex++;

                    if (currentIndex < audio.length) {
                        playNextAudio();
                    } else {
                        stopAndReleaseMediaPlayerss();
                        Intent gohome2 = new Intent(ChoiceA2.this, Game.class);
                        gohome2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(gohome2);
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAndReleaseMediaPlayerss();
    }

    private void stopAndReleaseMediaPlayerss() {
        if (storyaudio != null) {
            if (storyaudio.isPlaying()) {
                storyaudio.stop();
            }
            storyaudio.release();
        }
    }

}