package com.example.lima_creativityapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ChoiceB2 extends AppCompatActivity {

    ConstraintLayout backgroundLayout;
    Button homebtn;
    TextView storytext;
    int currentIndex = 0;

    public MediaPlayer storyaudio;

    int[] audio = new int[]{R.raw.b2_part1, R.raw.b2_part2, R.raw.b2_part3};

    String[] story = new String[]{"You turn and sprint towards the door, but it's locked. ",
            "The creature lunges at you, its claws outstretched. ",
            "The last thing you saw was its glowing red eyes, and you have fallen in a deep slumber.\n" +
                    "END (DEATH BY UNKNOWN FORCE)"

    };

    int[] backgroundImages = new int[]{
            R.drawable.door,
            R.drawable.door,
            R.drawable.doorwithforce,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_b2);
        storytext = findViewById(R.id.storytext);
        backgroundLayout = findViewById(R.id.backgroundLayout7);

        homebtn = findViewById(R.id.homebtn);

        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAndReleaseMediaPlayerss();
                Intent gohome = new Intent(getApplicationContext(), Game.class);
                gohome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(gohome);
            }
        });

        playNextAudio();
    }

    public void playNextAudio() {
        if (currentIndex < audio.length) {
            storytext.setText(story[currentIndex]);
            storyaudio = MediaPlayer.create(getApplicationContext(), audio[currentIndex]);
            backgroundLayout.setBackgroundResource(backgroundImages[currentIndex]);

            storyaudio.start();

            // Play specific sound effects at certain audio indices
            if (currentIndex == 0) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.run);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            } else if (currentIndex == 1) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.monsterlunge);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }else if (currentIndex == 2) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.secondthud);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }

            storyaudio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    currentIndex++;

                    if (currentIndex < audio.length) {
                        playNextAudio();
                    } else {
                        stopAndReleaseMediaPlayerss();
                        Intent gohome2 = new Intent(getApplicationContext(), Game.class);
                        gohome2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(gohome2);
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAndReleaseMediaPlayerss();
    }

    private void stopAndReleaseMediaPlayerss() {
        if (storyaudio != null) {
            if (storyaudio.isPlaying()) {
                storyaudio.stop();
            }
            storyaudio.release();
        }
    }

}
