package com.example.lima_creativityapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ChoiceA extends AppCompatActivity {

    ConstraintLayout backgroundLayout;
    Button homebtn, choiceA, choiceB;
    TextView storytext;
    int currentIndex = 0;

    public MediaPlayer storyaudio;

    int[] audio = new int[]{R.raw.choice_a_part1, R.raw.choice_a_part2};

    String[] story = new String[]{"You decide to ignore the whisper and focus on finding an exit. As you wander through the dimly lit corridors, the whispers grow louder, closer. ",
            "Shadows dance on the walls, taking on grotesque shapes. Suddenly, a cold hand grabs your ankle.\n\n" + "What do you do?"

    };

    int[] backgroundImages = new int[]{
            R.drawable.corridor,
            R.drawable.corridor
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);
        storytext = findViewById(R.id.storytext);
        backgroundLayout = findViewById(R.id.backgroundLayout3);

        homebtn = findViewById(R.id.homebtn);
        choiceA = findViewById(R.id.choiceA);
        choiceB = findViewById(R.id.choiceB);

        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAndReleaseMediaPlayerss();
                Intent gohome = new Intent(ChoiceA.this, Game.class);
                gohome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(gohome);
            }
        });

        playNextAudio();
    }

    public void playNextAudio() {
        if (currentIndex < audio.length) {
            storytext.setText(story[currentIndex]);
            storyaudio = MediaPlayer.create(getApplicationContext(), audio[currentIndex]);
            backgroundLayout.setBackgroundResource(backgroundImages[currentIndex]);

            storyaudio.start();

            // Play specific sound effects at certain audio indices
            if (currentIndex == 0) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.demonicwhisper);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            } else if (currentIndex == 1) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.skeletongrab);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }

            storyaudio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    currentIndex++;

                    if (currentIndex < audio.length) {
                        playNextAudio();
                    } else {

                        choiceA = findViewById(R.id.choiceA);
                        choiceA.setVisibility(View.VISIBLE);
                        choiceA.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent gotoChoiceA = new Intent(getApplicationContext(), ChoiceA1.class);
                                startActivity(gotoChoiceA);
                            }
                        });
                        choiceB = findViewById(R.id.choiceB);
                        choiceB.setVisibility(View.VISIBLE);
                        choiceB.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent gotoChoiceB = new Intent(getApplicationContext(), ChoiceA2.class);
                                startActivity(gotoChoiceB);
                            }
                        });
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAndReleaseMediaPlayerss();
    }

    private void stopAndReleaseMediaPlayerss() {
        if (storyaudio != null) {
            if (storyaudio.isPlaying()) {
                storyaudio.stop();
            }
            storyaudio.release();
        }
    }

}