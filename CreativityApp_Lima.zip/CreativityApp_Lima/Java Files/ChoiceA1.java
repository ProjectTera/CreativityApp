package com.example.lima_creativityapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ChoiceA1 extends AppCompatActivity {

    ConstraintLayout backgroundLayout;
    Button homebtn;
    TextView storytext;
    int currentIndex = 0;

    public MediaPlayer storyaudio;

    int[] audio = new int[]{R.raw.a1_part1, R.raw.a1_part2, R.raw.a1_part3, R.raw.a1_part4};

    String[] story = new String[]{"You let out a blood-curdling scream, struggling against the unseen force. ",
            "The creature's grip tightens, and you feel a sharp pain in your ankle.",
            "In a desparate move, you tried to shake it off but eventually pulled you to somewhere. ",
            "You're consumed by darkness.\n\n" + "END (DARK VOID)"

    };

    int[] backgroundImages = new int[]{
            R.drawable.corridor,
            R.drawable.corridor,
            R.drawable.corridor,
            R.drawable.darkness
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_a1);
        storytext = findViewById(R.id.storytext);
        backgroundLayout = findViewById(R.id.backgroundLayout4);

        homebtn = findViewById(R.id.homebtn);

        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAndReleaseMediaPlayerss();
                Intent gohome = new Intent(ChoiceA1.this, Game.class);
                gohome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(gohome);
            }
        });

        playNextAudio();
    }

    public void playNextAudio() {
        if (currentIndex < audio.length) {
            storytext.setText(story[currentIndex]);
            storyaudio = MediaPlayer.create(getApplicationContext(), audio[currentIndex]);
            backgroundLayout.setBackgroundResource(backgroundImages[currentIndex]);

            storyaudio.start();

            // Play specific sound effects at certain audio indices
            if (currentIndex == 0) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.bloodcurdlingscream);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            } else if (currentIndex == 1) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.tightgrip);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }else if (currentIndex == 2) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.fightback);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }else if (currentIndex == 3) {
                MediaPlayer soundEffectPlayer = MediaPlayer.create(getApplicationContext(), R.raw.pulledtodarkness);
                soundEffectPlayer.start();
                soundEffectPlayer.setOnCompletionListener(mp -> mp.release());
            }

            storyaudio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    currentIndex++;

                    if (currentIndex < audio.length) {
                        playNextAudio();
                    } else {
                        stopAndReleaseMediaPlayerss();
                        Intent gohome = new Intent(ChoiceA1.this, Game.class);
                        gohome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(gohome);
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAndReleaseMediaPlayerss();
    }

    private void stopAndReleaseMediaPlayerss() {
        if (storyaudio != null) {
            if (storyaudio.isPlaying()) {
                storyaudio.stop();
            }
            storyaudio.release();
        }
    }

}